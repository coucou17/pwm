// server.js
const express = require("express");
const cookieParser = require("cookie-parser");
const jwt = require("jsonwebtoken");
const mysql = require("mysql2/promise");
const nodemailer = require("nodemailer");



const app = express();
const PORT = 3000;

const JWT_SECRET = "la_mia_chiave_segreta";

app.use(express.json());
app.use(cookieParser());
app.use(express.static("public"));
app.use("/immagini", express.static("immagini"));



// creo una connessione al db 
const pool = mysql.createPool({
  host: "localhost",
  user: "root",       
  password: "Francette04!",   
  database: "mio_db",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

app.get("/", (req,res) => {  //redirect iniziale nella home
  res.redirect("/index.html");
});


// Middleware per proteggere i route
function isAuthenticated(req, res, next) {
    const token = req.cookies.token;
    if (!token) return res.status(401).json({ authenticated: false, message: "Non autorisé" });
       try {
        const user = jwt.verify(token, JWT_SECRET);
        req.user = user;
        next();
    } catch (err) {
        return res.status(403).redirect("/index.html");
    }
}


  /* ============================
           ROUTES API
============================ */


// LOGIN (nom + email)
app.post("/login", async (req, res) => {
  const { nome, email } = req.body;
  if (!nome || !email) {
    return res.status(400).json({ authenticated: false, message: "Tutti i campi sono obbligatori" });
  }

  try {
    const [rows] = await pool.execute(
      "SELECT id, nome, email FROM utenti WHERE nome = ? AND email = ?",
      [nome, email]
    );

    if (rows.length === 0) {
      return res.status(401).json({ authenticated: false, message: "Utente sconosciuto" });
    }

    const user = rows[0];

    // Creo il JWT (identificatore)
    const token = jwt.sign(
      { id: user.id, nome: user.nome, email: user.email },
      JWT_SECRET,
      { algorithm: "HS256", expiresIn: "1h" }
    );

    // Inserisce il token in un cookie (contenitore)
    res.cookie("token", token, {
      httpOnly: true,
      sameSite: "Strict",
      maxAge: 3600000, // 1 ora
      secure: true             
    });

    return res.json({ authenticated: true, message: "Sei connesso" });
    
  } catch (err) {
    console.error(err);
    return res.status(500).json({ authenticated: false, message: "Erreur serveur" });
  }
});



//  LOGOUT (cancella il cookie)
app.post("/logout",isAuthenticated, (req, res) => {
  res.clearCookie("token");
  return res.json({ authenticated: true, message: "Déconnecté" });
});

// test se conneso
app.get("/api/profile", isAuthenticated, (req, res) => {
  return res.json({ authenticated: true, user: req.user }); // {id, nome, email}
});










// ===================
//   ROUTE REGISTER
// ===================
app.post("/register", async (req, res) => {
    const { nome, email } = req.body;

    if (!nome || !email) {
        return res.status(400).json({ registered: false, message: "Nome e mail sono obbligatori" });
    }

    try {
        // verifico se l'email esiste già
        const [rows] = await pool.query("SELECT * FROM utenti WHERE email = ?", [email]);
        if (rows.length > 0) {
            return res.status(400).json({ registered: false, message: "Questo mail è già usato da un altro utente" });
        }

        // inserisco un nuovo user
        await pool.query("INSERT INTO utenti (nome, email) VALUES (?, ?)", [nome, email]);

        return res.json({ registered: true, message: "Registrazione avvenuta con successo, ora puoi effettuare il login"});

    } catch (err) {
        console.error("Erreur inscription:", err);
        return res.status(500).json({ registered: false, message: "Erreur serveur durante la registrazione" });
    }
});












// Route per inviare la citazione
app.post("/send-citation", async (req, res) => {
  const { nom, citation, auteur, theme } = req.body;

  if (!nom || !citation || !auteur || !theme) {
    return res.status(400).json({ message: "Tutti i campi sono obbligatori" });
  }

  try {
    //createTransport({...}) : configura il servizio di posta elettronica.
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "kiminoufrancette@gmail.com",
        pass: "icdn uuoz jfao evxz"
      }
    });

    await transporter.sendMail({
      from: `"Mon site citations" <kiminoufrancette@gmail.com>`,
      to: "kiminoufrancette2@gmail.com",
      subject: "Nouvelle citation proposée",
      text: `Nom: ${nom}\nAuteur: ${auteur}\nThème: ${theme}\nCitation: ${citation}`
    });

    res.json({ message: "Votre citation a bien été envoyée !" });
 } catch (err) {
  console.error("Erreur email:", err);
  res.status(500).json({ message: "Impossible d'envoyer l'email", error: err.toString() });
}
});








// recupero tutti i critici (dal più vecchio al più recente)
app.get("/api/critiques", async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT c.id, c.nom, c.texte, c.date_publication, c.likes,
              COUNT(r.id) AS nb_reponses
       FROM critiques c
       LEFT JOIN reponses r ON c.id = r.critique_id
       GROUP BY c.id
       ORDER BY c.date_publication ASC`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Erreur serveur");
  }
});


app.post("/api/critiques", async (req, res) => {
  // recupero i dati inviati dal navigatore
  const { nom, texte, utilisateur_id } = req.body;
  if (!nom || !texte) return res.status(400).send("Nome e text sono obbligatori");

  // analizzo il testo
  const pos = ["jolie", "merci", "j'aime", "bon", "merveilleux"];
  const neg = ["déteste", "horrible", "nul", "moche", "affreux", "nulle"];

let sentiment = "neutre";
if (pos.some(word => texte.includes(word))) sentiment = "positif";
else if (neg.some(word => texte.includes(word))) sentiment = "negatif";

  // salvo nella BD
  await pool.query(
    "INSERT INTO critiques (nom, texte, utilisateur_id, sentiment) VALUES (?, ?, ?, ?)",
    [nom, texte, utilisateur_id || null, sentiment]
  );

  res.status(201).json({ message: "Recensione aggiunta ✅"});
});



// metter mi pice ad una critica (1 solo like per user)
app.post("/api/critiques/:id/like", async (req, res) => {
  const critiqueId = req.params.id;
  const { utilisateur_id } = req.body;

  if (!utilisateur_id)
    return res.status(400).send("Utente obbligatori");

  try {
    // verifico se il user ha già messo mi piace
    const [rows] = await pool.query(
      "SELECT * FROM likes WHERE critique_id = ? AND utilisateur_id = ?",
      [critiqueId, utilisateur_id]
    );

    if (rows.length > 0) {
      return res.status(400).send("Hai già messo un like a questo commento !");
    }

    // se no, inserisco il like
    await pool.query(
      "INSERT INTO likes (critique_id, utilisateur_id) VALUES (?, ?)",
      [critiqueId, utilisateur_id]
    );

    // Incremento il contatore
    await pool.query("UPDATE critiques SET likes = likes + 1 WHERE id = ?", [
      critiqueId,
    ]);

    res.json({ message: "Like aggiunto ✅" });
  } catch (err) {
    console.error(err);
    res.status(500).send("Erreur serveur");
  }
});




// risposta ad una critica
app.post("/api/critiques/:id/reponse", async (req, res) => {
  const critiqueId = req.params.id;
  const { nom, texte, utilisateur_id } = req.body;

  if (!texte)
    return res.status(400).send("scrivi qualcosa... ");


  // analizzo il testo
  const pos = ["jolie", "merci", "j'aime", "bon", "merveilleux"];
  const neg = ["déteste", "horrible", "nul", "moche", "affreux", "nulle"];

let sentiment = "neutre";
if (pos.some(word => texte.includes(word))) sentiment = "positif";
else if (neg.some(word => texte.includes(word))) sentiment = "negatif";


  try {
    await pool.query(
      "INSERT INTO reponses (critique_id, nom, texte, utilisateur_id, sentiment) VALUES (?, ?, ?, ?, ?)",
      [critiqueId, nom, texte, utilisateur_id || null, sentiment]
    );

    res.status(201).json({ message: "Risposta aggiunta ✅" });
  } catch (err) {
    console.error(err);
    res.status(500).send("Erreur serveur");
  }
});




// recuperare le risposte di una critica
app.get("/api/critiques/:id/reponses", async (req, res) => {
  const critiqueId = req.params.id;
  try {
    const [rows] = await pool.query(
      "SELECT * FROM reponses WHERE critique_id = ? ORDER BY date_reponse ASC",
      [critiqueId]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).send("Erreur serveur");
  }
});




app.get("/api/critiques/etat", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT sentiment, COUNT(*) AS total
      FROM critiques
      GROUP BY sentiment
    `);

    // inizializzazione
    let positif = 0;
    let negatif = 0;

    // analizzo i risultati
    rows.forEach(r => {
      if (r.sentiment === "positif") positif = r.total;
      if (r.sentiment === "negatif") negatif = r.total;
    });

    res.json({ positif, negatif });

  } catch (err) {
    console.error("Erreur /api/critiques/etat:", err);
    res.status(500).json({ error: "Errore nel calcolo delle recensioni" });
  }
});






// --- CITATIONS --- //
app.get("/api/citations", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM citations ORDER BY id");
    res.json(rows);
  } catch (err) {
    console.error("Erreur /api/citations:", err);
    res.status(500).json({ error: "Erreur serveur" });
  }
});



app.post("/api/citations/like", isAuthenticated, async (req, res) => {
  const { citation_id } = req.body;
  const userId = req.user.id; 
  if (!citation_id) return res.status(400).json({ error: "citation_id mancante" });

  try {
    // Verifico se user ha già messo un mi piace
    const [exists] = await pool.query(
      "SELECT 1 FROM citation_likes WHERE citation_id = ? AND utilisateur_id = ?",
      [citation_id, userId]
    );
    if (exists.length > 0) {
      return res.status(400).json({ error: "Déjà liké" });
    }

    // salvo il like
    await pool.query(
      "INSERT INTO citation_likes (citation_id, utilisateur_id) VALUES (?, ?)",
      [citation_id, userId]
    );

    // Incremento il contatore nella tabella citations
    await pool.query("UPDATE citations SET likes = likes + 1 WHERE id = ?", [citation_id]);

    // recupero il nuovo totale
    const [[{ likes }]] = await pool.query("SELECT likes FROM citations WHERE id = ?", [citation_id]);

    res.json({ success: true, likes });
  } catch (err) {
    console.error("Erreur POST /api/citations/like:", err);
    res.status(500).json({ error: "Erreur serveur" });
  }
});



// recupero la somma dei like per tema
app.get("/api/citations/likes-by-theme", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT theme, SUM(likes) AS total_likes
      FROM citations
      GROUP BY theme
    `);

    res.json(rows.length ? rows : []);
  } catch (err) {
    console.error("Erreur /api/citations/likes-by-theme:", err);
    res.status(500).json({ message: "Errore del server durante il calcolo dei Mi piace per argomento" });
  }
});


app.use((req, res) => {
 res.status(404).send('Errore 404 - Risorsa non trovata');
});









app.listen(PORT, () => {
  console.log(`Serveur lancé sur http://localhost:${PORT}`);
});







